﻿using UnityEngine;
using System.Collections;

public class RandomColors : MonoBehaviour {

	private Color[] colors = new Color[6];

	// Use this for initialization
	void Start () {
	
		colors[0] = Color.cyan;
		colors[1] = Color.red;
		colors[2] = Color.green;
		colors[3] = new Color(255, 165, 0);
		colors[4] = Color.yellow;
		colors[5] = Color.magenta;

		foreach (Transform goItem in transform) {
			
			foreach (Transform item in goItem) {
				
				MeshRenderer r = item.GetComponent<MeshRenderer> ();

				if (r) {
					
					Material m = r.material;

					if (m) {
						
						Color c = colors [Random.Range (0, colors.Length)];
						m.SetColor ("_Diffusecolor", c);
						m.SetColor ("_Speccolor", c);
					}
				}
			}
		}
	}
}
