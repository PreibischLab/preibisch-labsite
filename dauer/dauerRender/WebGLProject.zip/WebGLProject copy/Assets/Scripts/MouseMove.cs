﻿using UnityEngine;

public class MouseMove : MonoBehaviour {

    public GameObject centerObject;

    public float horizontalSpeed = 1.0f;
    public float verticalSpeed = 1.0f;

    private enum MouseMovementMode
    {
        NONE = 0,
        ROTATION = 1,
        TRANSLATION = 2,
        ZOOM = 3
    }

    private MouseMovementMode m_eMovementMode = MouseMovementMode.NONE;

    private Vector3 m_lastMousePosition;

    void Update()
    {
        // Choose the correct movement mode -
        // Left Mouse Button = Rotation
        // Left Mouse Button + Left/Right Shift Key = Translation
        if (Input.GetMouseButton(0))
        {
            if (Input.GetKey(KeyCode.LeftShift) ||
                Input.GetKey(KeyCode.RightShift))
            {
                Debug.Log("Mouse Mode: TRANSLATION");
                m_eMovementMode = MouseMovementMode.TRANSLATION;
            }
            else
            {
                Debug.Log("Mouse Mode: ROTATION");
                m_eMovementMode = MouseMovementMode.ROTATION;
            }
        }
        else if (Input.mouseScrollDelta != Vector2.zero)
        {
            Debug.Log("Mouse Mode: ZOOM " + Input.mouseScrollDelta.ToString());
            m_eMovementMode = MouseMovementMode.ZOOM;
        }
        else
        {
            //Debug.Log("Mouse Mode: NONE");
            m_eMovementMode = MouseMovementMode.NONE;
        }

        // Handle translation mode movement
        if (m_eMovementMode == MouseMovementMode.TRANSLATION ||
            m_eMovementMode == MouseMovementMode.ROTATION)
        {
            // Track the change in X,Y
            float AxisMouseX = (Input.mousePosition.x - m_lastMousePosition.x) / Screen.width / Time.deltaTime;
            float AxisMouseY = (Input.mousePosition.y - m_lastMousePosition.y) / Screen.height / Time.deltaTime;

            // Add some speed to it
            float h = horizontalSpeed * AxisMouseY;// Input.GetAxis("Mouse Y");
            float v = verticalSpeed * AxisMouseX; // Input.GetAxis("Mouse X");

            // Change the camera position
            transform.Translate(v, h, 0);

            if (m_eMovementMode == MouseMovementMode.ROTATION)
            {
                transform.LookAt(centerObject.transform);
            }
        }
        
        // Save the last position of the mouse
        m_lastMousePosition = Input.mousePosition;
    }
}
